
<?
include "coneccion.php";
$id=$_GET["id"];
if($id==999999){
 

$dato=" <label for=\"guaranteed_length\">Numero de parte :</label><select class=\"form-control\" id=\"parte\" name=\"parte\"  onChange=\"buscaParte(parte.value)\"><option value=\"0\" disabled=\"true\">--Selecciona Numero de Parte--</option>";
	
	
	echo"$dato";
	
   
   
}
else{	
	$dato="";
	$consulta  = "select programa_parte.parte, parte.producto from programa_parte inner join parte on parte.parte=programa_parte.parte    where programa='$id' and programa_parte.deleted_at is null group by programa_parte.parte, parte.producto order by programa_parte.parte";	
	//echo"$consulta";
	$resultado = mysql_query($consulta) or die("");
	
	$count=1;
	$dato=" <label for=\"guaranteed_length\">Numero de parte :</label><select class=\"form-control\" id=\"parte\" name=\"parte\" onChange=\"buscaParte(parte.value)\"><option value=\"0\" selected=\"selected\">--Selecciona Numero de Parte--</option>";
	while(@mysql_num_rows($resultado)>=$count)
	{		
		
		$res=mysql_fetch_row($resultado);
		
		$dato=$dato."<option value=\"$res[0]\" >$res[0] - $res[1]</option>";
		$count++;		
	}
	
		echo"$dato";
		
		
	
	}
?>