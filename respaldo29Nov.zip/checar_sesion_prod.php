<?
session_start();


if ($_SESSION['idU']=="" || !$_SESSION['idU'] ){

	include "index.php";

exit();

}

?>