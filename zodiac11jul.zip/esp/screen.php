<?
session_start();
include "coneccion.php";

$idU=$_SESSION['idU'];
$nombreU=$_SESSION['nombreU'];
$tipoU=$_SESSION['tipoU'];
$locationU=$_SESSION['location'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Zodiac - Cortes</title>
    <link rel="shortcut icon" href="public/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="public/css/bootstrap/bootstrap.min.css"/>
    <link rel="stylesheet" href="public/css/bootstrap/bootstrap-theme.min.css"/>
    <link rel="stylesheet" href="public/css/font-awesome/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="public/css/metisMenu/metisMenu.min.css"/>
    <link rel="stylesheet" href="public/css/sb-admin-2/sb-admin-2.css"/>
    <link rel="stylesheet" href="public/css/jqueryui/jquery-ui.min.css">
    <link rel="stylesheet" href="public/css/jqueryui/jquery-ui.structure.min.css">
    <link rel="stylesheet" href="public/css/jqueryui/jquery-ui.theme.min.css">
    <link rel="stylesheet" href="public/css/style.css"/>
    <link rel="stylesheet" href="public/css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/css/select2.min.css" rel="stylesheet" />
	
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		 
  <script src="colorbox/jquery.colorbox-min.js" type="text/javascript"></script>
<link rel="stylesheet" href="colorbox/colorbox.css" />
  <script type="text/javascript">
  $(function(){
    $(".iframe3").live('click',function(e){
         e.preventDefault();
         $.colorbox({
              width:"420", 
              href:$(this).attr('href'),
              height:"430", 
              iframe:true, 
              onClosed:function(){     
                   location.reload(true); 
              } 
         });
    });
});
 $(function(){
    $(".iframe1").live('click',function(e){
         e.preventDefault();
         $.colorbox({
              width:"860", 
              href:$(this).attr('href'),
              height:"500", 
              iframe:true, 
              onClosed:function(){     
                   location.reload(true); 
              } 
         });
    });
});
	$(document).ready(function(){
		//$(".iframe1").colorbox({iframe:true,width:"860", height:"500",transition:"fade", scrolling:true, opacity:0.7});
		$(".iframe2").colorbox({iframe:true,width:"600", height:"210",transition:"fade", scrolling:false, opacity:0.7});
		//$(".iframe3").colorbox({iframe:true,width:"420", height:"430",transition:"fade", scrolling:false, opacity:0.7});
		$("#click").click(function(){ 
		$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
			return false;
		});
	});

	function cerrarV(){
		$.fn.colorbox.close();
	}
function abrir(id)
{
	
$.colorbox({iframe2:true,href:"editar_corte_prod.php?id="+id,width:"420", height:"430",transition:"fade", scrolling:true, opacity:0.7});
	
}
function abrir2(id)
{
	
$.colorbox({iframe2:true,href:"editar_pausa_prod.php?id="+id,width:"820", height:"630",transition:"fade", scrolling:true, opacity:0.7});
	
}
</script>
<script>
        function textAreaAdjust(o) {
            o.style.height = "1px";
            o.style.height = (25+o.scrollHeight)+"px";
        }
		
    </script>
<?

?>
<script>
function borrar(id)
{
  if(confirm("Esta seguro de borrar este Corte?"))
  {
       document.form1.borrar.value=id;
	   document.form1.submit();
   }
}
function buscar()
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
    }
  }
  var tipo=0;
 
xmlhttp.open("GET","buscar_activos.php?id=<? echo"$locationU";?>",true);
xmlhttp.send();
}
function buscarO()
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("d_pendientes").innerHTML=xmlhttp.responseText;
    }
  }
  var tipo=0;
 
xmlhttp.open("GET","buscar_pendientes.php?id=<? echo"$locationU";?>",true);
xmlhttp.send();
}
function buscarT()
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("d_terminadas").innerHTML=xmlhttp.responseText;
    }
  }
  var tipo=0;
 
xmlhttp.open("GET","buscar_terminadas.php?id=<? echo"$locationU";?>",true);
xmlhttp.send();
}
</script>
<script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
function guardaMotivo(targ,selObj,ra){ //v3.0
  eval(targ+".location='cortes_prod.php?pause_id2="+ra+"&ra2="+selObj.value+"'");
  
}
//-->
</script>
<script async src="//jsfiddle.net/pmw57/tzYbU/205/embed/"></script>
<style type="text/css">
<!--
a {color: #FFFFFF; }
body {
	background-color: #000000;
}
.style1 {font-size: 18px}
.style2 {font-size: 24px}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="15"></head>
<body >
<div id="wrapper">
    <!-- Navigation onLoad="timer = setTimeout('auto_reload()',15000);"-->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><img class="img-responsive" src="public/images/zodiac.jpg" alt="zodiac logo"/></a>
    </div>
    <!-- /.navbar-header -->
    <? 
	//if($tipoU!="3")
	//	include "menu_f.php"
	//else
		include "menu_s.php"
	?>
    <!-- /.navbar-static-side -->
</nav>
    <div >
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Pantalla de Control </h1>
                <form action="" method="post" name="form1" id="form1">
                           
              <div class="col-lg-12 table-responsive" id="d_pendientes">
			  
                                                                    <table class="table table-striped table-condensed grid">
                            <thead>
							<tr>
                            <th width="11%" height="40"><span class="style2">Lectra</span></th>
                           
                            <th width="11%"><span class="style2">Status</span></th>
                            <th width="20%"><span class="style2">Operador</span></th>
                            <th width="15%"><span class="style2">MO</span></th>
                            <th width="25%"><span class="style2">Numero de Parte / Programa </span></th>
                            <th width="9%"><span class="style2">Tiempo Activo </span></th>
                            <th width="9%"><span class="style2">Tiempo Muerto </span></th>
                            </tr>
                            </thead>
                            <tbody>

                            
                                        
	<?	
	$contado=0;  
	$consulta  = "SELECT locations.id, locations.name, users.first_name  FROM locations left outer join users on locations.logged=users.id where locations.deleted_at is null  order by locations.name";
	
	//echo"$consulta";
	$resultado = mysql_query($consulta) or die("La consulta fall&oacute;P1: " . mysql_error());
	while($res=mysql_fetch_assoc($resultado))
	{	
		$consulta2  = "SELECT cuts.id,mo, cn, cut_type.nombre, length_measured, locations.name, location_capacities.number, rolls.lote, roll_fibers.fiber_type, rolls.remaining_inches, cuts.status, cuts.parte,cuts.length_consumed, cuts.length_defect,DATE_FORMAT(date_lote, '%m-%d-%Y'), programas.nombre as prog, TIMESTAMPDIFF(MINUTE, cuts.hardware_init, now()) as d1, TIMESTAMPDIFF(MINUTE, cuts.hardware_init, cuts.hardware_end) as d2, cuts.hardware_init, cuts.hardware_end, users.first_name  FROM cuts inner join cut_type on cut_type.id=cuts.id_cut_type inner join locations on cuts.location_assigned_id=locations.id left outer join location_capacities on cuts.number_position=location_capacities.id inner join rolls on rolls.id=cuts.roll_id inner join roll_fibers on cuts.fiber_id=roll_fibers.fiber_type left outer join programas on cuts.id_programa=programas.id left outer join users on locations.logged=users.id where cuts.deleted_at is null and cuts.location_assigned_id=".$res['id']." and cuts.orden=1";
	
		//echo"$consulta2";
		$resultado2 = mysql_query($consulta2) or die("La consulta fall&oacute;P1: " . mysql_error());
		if($res2=mysql_fetch_assoc($resultado2))
		{
			$pausa=0;
			$pausa2=0;
			if($res2['status']==0)
				$estatus="Inactivo";
			if($res2['status']==1)
				$estatus="En proceso";
			else
				$estatus="En pausa";
			
			$consulta4  = "SELECT sum(TIMESTAMPDIFF(MINUTE, inicio, fin)) as d1  FROM cut_pause where id_cut=".$res2['id']."  and fin is not null group by id_cut";
			//echo $consulta4;
			$resultado4 = mysql_query($consulta4) or die("La consulta fall&oacute;P1: " . mysql_error());
			while($res4=mysql_fetch_assoc($resultado4))
			{
				$pausa=$res4['d1'];
				//echo"pausa=".$pausa;
			}	
			
			$consulta4  = "SELECT TIMESTAMPDIFF(MINUTE, inicio, now()) as d1  FROM cut_pause where id_cut=".$res2['id']."  and fin is null";
			$resultado4 = mysql_query($consulta4) or die("La consulta fall&oacute;P1: " . mysql_error());
			while($res4=mysql_fetch_assoc($resultado4))
			{
				$pausa2=$res4['d1'];
				//echo"pausa2=".$pausa2;
			}
			if($res2['hardware_init']=='')
			{
				//echo"entra0".$res2['hardware_init'];
				$tiempo_activo="0";
				$tiempo_muerto="0";
			}
			else if($res2['hardware_end']=="")
			{
				//echo"entra1";
				$tiempo_muerto=$pausa+$pausa2;
				$tiempo_activo=$res2['d1']-$tiempo_muerto;
				
			}else if($res2['hardware_end']!="")
			{
				//echo"entra2";
				$tiempo_muerto=$pausa+$pausa2;
				$tiempo_activo=$res2['d2']-$tiempo_muerto;
				
			}
			
		?>
							<tr>
                                    <td height="30"><span class="style1"><? echo $res['name']?></span></td>
                                 
                                    <td><span class="style1"><? echo $estatus?></span></td>
                                    <td><span class="style1"><? echo $res2['first_name'] ?></span></td>
                                    <td><span class="style1"><? echo $res2['mo']?></span></td>

                                    <td><span class="style1"><? echo $res2['parte']?> / <? echo $res2['prog']?></span></td>
                                


                                    <td><span class="style1"><? echo $tiempo_activo?> MIN</span></td>
                                    <td><span class="style1"><? echo $tiempo_muerto?> MIN</span></td>
							</tr>
                                    <?  
						}else
						{
						?>
							<tr>
                                    <td height="30"><span class="style1"><? echo $res['name']?></span></td>
                                 
                                    <td><span class="style1">Inactivo</span></td>
                                    <td><span class="style1"><? echo $res['first_name'] ?></span></td>
                                    <td><span class="style1"></span></td>

                                    <td><span class="style1"></span></td>
                                


                                    <td><span class="style1"></span></td>
                                    <td><span class="style1"></span></td>
							</tr>
                                    <?
						}
					}?>
									   </tbody>                     
                                                    </table>
              </div>
</form>
                

            </div>
        </div>
    </div>
</div><footer>
    
    <script src="public/js/bootstrap/bootstrap.min.js"></script>
    <script src="public/js/metisMenu/metisMenu.min.js"></script>
    <script src="public/js/sb-admin-2/sb-admin-2.js"></script>
    <script src="public/js/jquery-ui.min.js"></script>
    <script src="public/js/search.js"></script>
    <script src="public/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.2/js/select2.min.js"></script>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function(){
            $("area[rel^='prettyPhoto']").prettyPhoto();

            $(".gallery:first a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: false});
            $(".gallery:gt(0) a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'fast',slideshow:10000, hideflash: true});

            $("#custom_content a[rel^='prettyPhoto']:first").prettyPhoto({
                custom_markup: '<div id="map_canvas" style="width:260px; height:265px"></div>',
                changepicturecallback: function(){ initialize(); }
            });

            $("#custom_content a[rel^='prettyPhoto']:last").prettyPhoto({
                custom_markup: '<div id="bsap_1259344" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div><div id="bsap_1237859" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6" style="height:260px"></div><div id="bsap_1251710" class="bsarocks bsap_d49a0984d0f377271ccbf01a33f2b6d6"></div>',
                changepicturecallback: function(){ _bsap.exec(); }
            });
        });
    </script>
    <script  type="text/javascript" charset="utf-8">
        $('.datepick').each(function(){
            $(this).datepicker({ dateFormat: 'yy-mm-dd' });
        });
    </script>



    <script>
        $(function(){
                $('#Recurrent').change(function(){
                    if ($(this).prop('checked')){
                        $('#calArea').prop('disabled', true).animate({
                            opacity: 0
                        });
                            $('#Recurrent').val(1);

                    }
                    else{
                        $('#calArea').prop('disabled', false).animate({
                            opacity: 1
                        });
                        $('#Recurrent').val(0);

                    }
                })
            }
        )
		/////////////////////////////
		/*buscar();
		window.setInterval(function(){
  		buscar();
		},10000);
		window.setInterval(function(){
  		buscarO();
		},15000);
		window.setInterval(function(){
  		buscarT();
		},16000);*/
		
		/*function auto_reload()
		{
			window.location = 'cortes_prod.php';
		}*/
		//myFunction();
    </script>
</footer>
</body>
</html>